const scopesArray = ["openid", "profile", "read:playlists", "delete:playlists"];

export default scopesArray;
