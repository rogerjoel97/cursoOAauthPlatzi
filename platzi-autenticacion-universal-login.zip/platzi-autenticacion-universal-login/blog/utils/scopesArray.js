const scopesArray = [
  "user-read-private",
  "user-read-email",
  "playlist-read-collaborative"
];

module.exports = scopesArray;
